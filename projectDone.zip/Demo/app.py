from flask import Flask
from flask import render_template
from flask import request
import psycopg2 

app = Flask(__name__)

def create_connection():
    conn = psycopg2.connect(
            host="localhost",
            database="postgres",
            user='postgres',
            password='Ght57qup0906')
    return conn

@app.route("/")
def index():
    return render_template('index.html')
@app.route("/book_traning", methods=['POST'])
def book_traning():
    conn= create_connection()
    email = request.form['user_email']
    date_and_time = request.form['time']
    client = request.form['client']
    place = request.form['location']
    cur = conn.cursor()
    cur.execute('INSERT INTO booking (email, client, place, date_and_time)'
                'Values(%s, %s, %s, %s::timestamp)',
                (email, client, place, date_and_time))
    conn.commit()
    conn.close()
    return (f'Training booked for {client} at the {date_and_time}, with the email {email}!')

@app.route("/bookings", methods=['GET'])
def bookings():
    conn = create_connection()
    cur=conn.cursor()
    cur.execute('SELECT * FROM booking ORDER BY date_and_time ASC')
    bookings = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('bookings.html', bookings=bookings)

@app.route("/about",)
def about():
    return render_template('about.html')




    
