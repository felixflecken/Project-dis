1. First run schema.sql in postgres with pgadmin with the query tool. 
2. Insert sample_data.sql into. Optional. Sample data will be saved, every time a booking is made from the website.
3. Run "python -m flask --app app run --debug"


