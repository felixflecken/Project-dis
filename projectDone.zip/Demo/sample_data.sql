
INSERT INTO booking(
email, client, place, date_and_time
)VALUES
('Felixfl@live.dk','Oliver','Nøerrebrohallen','2023-06-23T12:00'::timestamp),
('mail@1.com','Oliver1','Nøerrebrohallen','2023-06-23T14:00'::timestamp),
('mail@2.com','Oliver2','Nøerrebrohallen','2023-07-23T14:00'::timestamp);