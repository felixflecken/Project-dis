

DROP TABLE booking;
CREATE TABLE IF NOT EXISTS booking(
    id serial PRIMARY KEY,
    email text,
    client text,
    place text, 
    date_and_time timestamp
);

